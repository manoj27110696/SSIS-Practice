CREATE TABLE PRODSSIS_ZIPCODE 
(
ZipCode Char(5),
State Char(2),
ZipName Varchar(16)
)